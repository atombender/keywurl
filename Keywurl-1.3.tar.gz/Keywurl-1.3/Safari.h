#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>
#import <Foundation/Foundation.h>

#ifdef KEYWURL_SAFARI_2_0
    #import "Safari2_0.h"
#else
    #import "Safari3_0.h"
#endif

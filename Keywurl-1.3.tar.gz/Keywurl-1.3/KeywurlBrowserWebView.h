#import <Cocoa/Cocoa.h>
#import "Safari.h"

@interface KeywurlBrowserWebView : BrowserWebView
@end

#import <Cocoa/Cocoa.h>
#import "Safari.h"

@interface KeywurlBrowserWindowController : BrowserWindowController
@end
